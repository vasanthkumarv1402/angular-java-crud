Summary


- In the "angular" folder, you will find an angular project 
- and in the "java" folder, you will find java rest API code
- In the "database" folder, you will find the database file

The database used as postgress
